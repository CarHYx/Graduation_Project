using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchAnimaton : MonoBehaviour
{
    private Animator anim;
    private new Rigidbody2D rigidbody2D;
    private Player playerBehavior;
    private PhysicsCheck physicsCheck;
    // Start is called before the first frame update
    void Start()
    {
        anim = this.GetComponent<Animator>();
        rigidbody2D = this.GetComponent<Rigidbody2D>();
        playerBehavior = this.GetComponent<Player>();
        physicsCheck = this.GetComponent<PhysicsCheck>();

    }

    // Update is called once per frame
    void Update()
    {
        SetAnimation();
    }

    private void SetAnimation()
    {
        anim.SetFloat("Walk", Mathf.Abs(rigidbody2D.velocity.x));
        anim.SetInteger("Run", (int)playerBehavior.isRun);
        anim.SetFloat("jumpY", rigidbody2D.velocity.y);
        anim.SetBool("isGround", physicsCheck.isGround);
        anim.SetBool("isDead", playerBehavior.isDead);
        anim.SetBool("isAttk", playerBehavior.isAtk);
    }
    public void SetHurt()
    {
        anim.SetTrigger("hurt");
    }
    public void SetAttack()
    {
        anim.SetTrigger("attack");

    }


}
