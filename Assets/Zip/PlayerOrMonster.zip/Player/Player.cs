using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
/// <summary>
/// The player.
/// </summary>

public class Player : PlayerBase
{
    protected PlayerInputController _playerInputsControl;
    protected Vector2 inputDirection => _playerInputsControl.GamePlayer.PlayerMove.ReadValue<Vector2>();

    public float isRun;
    public float speed = 10;
    private SpriteRenderer _sprite;
    private Rigidbody2D _rigidbody2D;
    public bool isDead;
    public bool isAtk;
    private PhysicsCheck _physicsCheck;
    public float jumpForce;
    private SwitchAnimaton _switchAnimaton;
    public float atkIntervals;         //�������ʱ��
    public float hurtIntervals;
    public float hp = 100;
    public float atk;
    protected override void Awake()
    {
        _playerInputsControl = new PlayerInputController();
         _sprite = this.GetComponent<SpriteRenderer>();
        _rigidbody2D = this.GetComponent<Rigidbody2D>();
        _physicsCheck = this.GetComponent<PhysicsCheck>();
        _switchAnimaton = this.GetComponent<SwitchAnimaton>();
    }
    protected override void OnEnable()
    {
        _playerInputsControl.GamePlayer.Enable();
    }
    /// <summary>
    /// Ons the disable.
    /// </summary>
    protected override void OnDisable()
    {
        //����ͬ��
        _playerInputsControl.GamePlayer.Disable();
    }
    /// <summary>
    /// Inits the.
    /// </summary>
    public override void Init()
    {
        PlayerManger.GetInstance().SaveData();
        _playerInputsControl.GamePlayer.Jump.started += PlayerJump;
        _playerInputsControl.GamePlayer.Atk.started += PlayerAtk;
    }
    /// <summary>
    /// Updates the.
    /// </summary>
    protected override void Update()
    {
        base.Update();
        if (inputDirection.x == 0)
        {
            isRun = 0;
            return;
        }
        isRun = _playerInputsControl.GamePlayer.Run.ReadValue<float>();

    }
    /// <summary>
    /// Fixeds the update.
    /// </summary>
    protected override void FixedUpdate()
    {
        base.FixedUpdate();
        if (!isDead)
            PlayerMove(inputDirection);
    }

    /// <summary>Players the move.</summary>
    /// <param name="inputDirection">The input direction.</param>
    public override void PlayerMove(Vector2 inputDirection)
    {

        if (isRun == 1)
        {
            _rigidbody2D.velocity = new Vector2(inputDirection.x * speed * Time.deltaTime * 2, _rigidbody2D.velocity.y);  //����
            Debug.Log("1");
        }
        else
            _rigidbody2D.velocity = new Vector2(inputDirection.x * speed * Time.deltaTime, _rigidbody2D.velocity.y);  //����
        if (inputDirection.x > 0)
            _sprite.flipX = false;
        if (inputDirection.x < 0)
            _sprite.flipX = true;

    }


    public override void PlayerJump(InputAction.CallbackContext context)
    {
        if(_physicsCheck.isGround)
            _rigidbody2D.AddForce(transform.up * jumpForce, ForceMode2D.Impulse);

    }

    public override void PlayerAtk(InputAction.CallbackContext context)
    {
        //Debug.Log(atkIntervals);
        if (TriggerInvulnerable(atkIntervals))
        {
            _switchAnimaton.SetAttack();
            isAtk = true;
        }
        else
        {
            isAtk = false;
        }


    }

    public bool isHurt;
    public override void PlayerHurt(float atk, UnityAction callback)
    {
        base.PlayerHurt(atk, callback);
        if (TriggerInvulnerable(hurtIntervals))
        {
            hp -= atk;
            _switchAnimaton.SetHurt();
            isHurt = true;
        }
        else
        {
            isHurt = false;
        }

    }
    public float hurtForce;
    public void HurtBehaviour(Transform other)
    {
        _rigidbody2D.velocity = Vector2.zero;
        Vector2 dir = new Vector2((this.transform.position.x - other.position.x), 0).normalized;
        if (isHurt)
            _rigidbody2D.AddForce(dir * hurtForce * 10);
    }
}
