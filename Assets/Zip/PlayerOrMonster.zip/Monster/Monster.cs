using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

public class Monster : MonsterBase
{
    public float atk = 10;
    public float hp = 100;
    private Rigidbody2D _rigidbody2D;
    public override void Init()
    {
        //throw new System.NotImplementedException();
        _rigidbody2D = this.GetComponent<Rigidbody2D>();
    }


    public override void MonsterAtk(InputAction.CallbackContext context)
    {
        base.MonsterAtk(context);
    }
    public override void MonsterHurt(float atk, UnityAction callback)
    {
        base.MonsterHurt(atk, callback);
    }

    public float hurtForce;
    public void HurtBehaviour(Transform other)
    {
        _rigidbody2D.velocity = Vector2.zero;
        Vector2 dir = new Vector2((this.transform.position.x - other.position.x), 0).normalized;
        Debug.Log(dir);
        _rigidbody2D.AddForce(dir * hurtForce * 100, ForceMode2D.Impulse);
    }

}
