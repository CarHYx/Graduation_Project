using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class PhysicsCheck : MonoBehaviour
{
    public bool isGround = true;
    public float chenkRaduis;
    public LayerMask groundLayer;
    public Vector2 bottomOffset;
    public GameObject player;
    public GameObject monster;

    private void Start()
    {

    }


    private void Update()
    {
        Check();
    }
    public void Check()
    {
        isGround = Physics2D.OverlapCircle((Vector2)transform.position + bottomOffset, chenkRaduis, groundLayer);
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere((Vector2)transform.position + bottomOffset, chenkRaduis);
    }

    /// <summary>
    /// Called when [trigger stay2 d].
    /// </summary>
    /// <param name="collision">The collision.��������ײ��Ϣ</param>
    private void OnTriggerStay2D(Collider2D collision)
    {
        player.gameObject.GetComponent<Player>().PlayerHurt(monster.GetComponent<Monster>().atk, () =>
        {
            player.gameObject.GetComponent<Player>().HurtBehaviour(monster.transform);
        });
        if (player.gameObject.name == "player")
        {

        }
        if(monster.gameObject.name == "monster")
        {
            monster.gameObject.GetComponent<Monster>().MonsterHurt(player.GetComponent<Player>().atk, () =>
            {
                monster.gameObject.GetComponent<Monster>().HurtBehaviour(player.transform);
            });
        }
    }





}
