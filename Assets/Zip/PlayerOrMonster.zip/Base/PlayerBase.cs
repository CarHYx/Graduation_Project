using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityEngine.WSA;

public abstract class PlayerBase : MonoBehaviour
{
    private float invulnerableCounter;
    protected bool invulnerable;


    protected virtual void OnEnable() { }
    protected virtual void OnDisable() { }
    protected virtual void Awake() 
    {
     
    }
    protected virtual void Start() 
    {
        Init();
    }
    protected virtual void Update() 
    {
        if (invulnerable)
        {
            invulnerableCounter -= Time.deltaTime;
            if (invulnerableCounter < 0)
            {
                invulnerable = false;
            }
        }
    }
    protected virtual void FixedUpdate() { }

    public abstract void Init();

    //�ƶ�
    public virtual void PlayerMove(Vector2 inputDirection)
    {



    }
    //��Ծ
    public virtual void PlayerJump(InputAction.CallbackContext context)
    {

    }
    public virtual void PlayerAtk(InputAction.CallbackContext context)
    {
        
    }
    //����
    public virtual void PlayerHurt(float atk , UnityAction callback)
    {
        callback?.Invoke();
    }
    //����
    public virtual void PlayerDead()
    {

    }
    //����л�����
    public virtual void PlayerAnimation()
    {

    }

    /// <summary>
    /// Triggers the invulnerable.��ʱ��
    /// </summary>
    /// <param name="invulnerableDuration">���ʱ��Duration of the invulnerable.</param>
    public bool TriggerInvulnerable(float invulnerableDuration = 2)
    {
        if (!invulnerable)
        {
            invulnerable = true;
            invulnerableCounter = invulnerableDuration;
            return true;
        }
        return false;
    }

}
